// Javascript Document

console.log("javascript is linked");